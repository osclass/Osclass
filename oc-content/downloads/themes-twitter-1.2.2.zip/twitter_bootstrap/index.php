<?php

    function twitter_bootstrap_theme_info() {
        return array(
             'name'        => 'Twitter theme'
            ,'version'     => '1.2.2'
            ,'description' => 'OSClass theme using twitter bootstrap'
            ,'author_name' => 'OSClass team'
            ,'author_url'  => 'http://osclass.org/'
            ,'locations'   => array('header', 'footer')
        );
    }

?>