#CHANGELOG

### v1.2.2 - 20/02/2012

* Removed usage of console.log function in js
* Fixed domain of a i18n string

### v1.1.1 - 19/10/2011

* reCAPTCHA in contact form is aligned to send button
* City select is populated even if there is only one region
* topbar color links
* topbar height, it doesn't hover the search form
* title text is now showed if there is a logo